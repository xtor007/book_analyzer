from Interface import Interface

interface = Interface()
interface.go()